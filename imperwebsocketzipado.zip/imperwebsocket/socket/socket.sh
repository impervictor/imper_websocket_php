php socket/socket.php &
exec "$@"
